package in.gov.uidai.model;

import java.sql.Connection;
import java.sql.SQLException;

public interface EIDValidator {

    boolean IsEIDFirstHalfValid(String EID_FirstHalf, Connection connection) throws ClassNotFoundException, SQLException;
    boolean IsEIDSecondHalfValid(String EID_SecondHalf);


}
