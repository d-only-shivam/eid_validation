package in.gov.uidai.model;

import java.sql.Connection;
import java.sql.SQLException;

public class EidLatestValidatorImpl implements EIDValidator {
    public boolean IsEIDFirstHalfValid(String EID_FirstHalf, Connection connection) throws ClassNotFoundException, SQLException {
        // call random location get status
        return false;
    }

    public boolean IsEIDSecondHalfValid(String EID_SecondHalf) {
        return false;
    }
}
