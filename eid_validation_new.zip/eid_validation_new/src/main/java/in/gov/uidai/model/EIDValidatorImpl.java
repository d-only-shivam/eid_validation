package in.gov.uidai.model;

import java.sql.*;

public abstract class EIDValidatorImpl implements EIDValidator {

    public boolean IsEIDFirstHalfValid(String EID_FirstHalf, Connection connection) throws ClassNotFoundException, SQLException {
        String EA_Code = EID_FirstHalf.substring(0,4);
        String Station_Code = EID_FirstHalf.substring(4,9);

        System.out.println("Done");
        String query = "SELECT count(*) from first_validation where ea_code = ? and station_code = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1, EA_Code);
        ps.setString(2,Station_Code);

        ResultSet resultSet = ps.executeQuery();
        if(resultSet.next()) {
            int count = resultSet.getInt(1);

            if(count<=1) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }


}
